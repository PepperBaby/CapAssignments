function dispHello()
{
//TODO:return the string “Hello World“
var str="Hello World";
return str;
}